package com.wrox.site;

public interface GreetingService
{
    public String getGreeting(String name);
}
